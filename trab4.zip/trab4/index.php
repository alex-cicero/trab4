<?php

	header("Location: emprestimo.php");
