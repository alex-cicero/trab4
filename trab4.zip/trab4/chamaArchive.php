<?php
    echo "<html> <head> <meta charset ='utf-8'> </head> <body style='text-align: center;'>";
    echo "<div style='background-color: white;'";
    echo "<br><br>";
    echo "<a href=\"testeConsulta1.php\">Gráfico 1</a>"; //quantos livros por genero [Ficção] [Academico] EM PIE
    echo "                                                               ";
    echo "<a href=\"testeConsulta2.php\">Gráfico 2</a>"; //quantos livros por subgenero do genero Academico EM PIE
    echo "                                                               ";
    echo "<a href=\"testeConsulta3.php\">Gráfico 3</a>"; //quantos livros por subgenero do genero Ficção EM PIE
    echo "<br><br> </div> <br><br>";
    echo "</body></html>";
?>
