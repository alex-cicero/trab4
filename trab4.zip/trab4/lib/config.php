<?php

	$config = array (
		'APP_PREFIX' => '/trab4',
		'DEFAULT_TIME_ZONE' => 'America/Sao_Paulo',
		'DB_HOST' => '127.0.0.1',
		'DB_USER' => 'root',
		'DB_DATABASE' => 'biblioteca',
		'DB_PASSWORD' => '',
	);

	$css = array (
		'lib/bootstrap-3.3.7-dist/css/bootstrap.min.css',
		'lib/main.css',
	);

	$headjs = array (
		'lib/jquery-3.2.1.min.js',
		'lib/main.js',
	);

	$endjs = array (
		'lib/bootstrap-3.3.7-dist/js/bootstrap.min.js',
	);
