<?php
  echo "Erro ao realizar empréstimo. Tente novamente.";
  header('location: emprestimo.php');
?>
