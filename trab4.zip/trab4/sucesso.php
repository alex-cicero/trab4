<?php
  echo "Empréstimo realizado com sucesso!"; //deveria ser um alert, mas dá erro :/
  header('location: emprestimo.php');
?>
